﻿using System.Collections.Generic;

namespace EF_CodeFirst.Model
{
    public class Category
    {
        public int CategoryID { get; set; }

        public string Name { get; set; }

        public virtual ICollection<Product> Products { get; set; }
    }
}