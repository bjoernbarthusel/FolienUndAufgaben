﻿using Microsoft.EntityFrameworkCore;

namespace EF_CodeFirst.Model
{
    public class ProductContext : DbContext
    {
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }

        public ProductContext()
        {
            // Falls die Datenbank noch nicht existiert, diese erstellen
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Der Connection String sollte besser in einer Konfigurationsdatei gespeichert werden            
            optionsBuilder.UseLazyLoadingProxies().UseSqlServer(@"Server=.\SQLEXPRESS;Database=ProductsDB;Integrated Security=True;MultipleActiveResultSets=True");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Die Tabelle für die Kategorien soll "Category" heißen 
            // und nicht "Categories" wie das DbSet
            modelBuilder.Entity<Category>().ToTable("Category");
            modelBuilder.Entity<Product>().ToTable("Product");
        }
    }
}
