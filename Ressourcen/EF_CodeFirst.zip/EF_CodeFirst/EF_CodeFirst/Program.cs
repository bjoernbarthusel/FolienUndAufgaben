﻿using EF_CodeFirst.Model;

namespace EF_CodeFirst
{
    internal class Program
    {
        // Install-Package Microsoft.EntityFrameworkCore -Version 6.0.11
        // Install-Package Microsoft.EntityFrameworkCore.SqlServer -Version 6.0.11
        // Install-Package Microsoft.EntityFrameworkCore.Proxies -Version 6.0.11
        static void Main(string[] args)
        {
            using (ProductContext ctx = new ProductContext())
            {
                Create(ctx);

                Read(ctx);

                Update(ctx);

                Read(ctx);

                Delete(ctx);

                Read(ctx);
            }
            Console.WriteLine("\nTaste zum Beenden");
            Console.ReadLine();
        }
        private static void Create(ProductContext ctx)
        {
            try
            {
                // Neue Kategorie erstellen
                Category support = new Category() { Name = "Support" };

                // Neues Produkt erstellen
                Product backup = new Product()
                {
                    Name = "Sicherung eines SQL Servers",
                    Price = 65.99,
                    Category = support
                };

                // Das Product-Objekt in das DbSet der Kontext-Klasse einfügen
                // Das Category-Objekt wird dadurch ebenfalls eingefügt
                ctx.Products.Add(backup);

                ctx.SaveChanges();

                Console.WriteLine("Daten eingefügt!");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void Read(ProductContext ctx)
        {
            try
            {
                // Alle Produkte mit Kategorie
                foreach (Product product in ctx.Products)
                {
                    Console.WriteLine("{0}, {1} Euro Kategorie: {2}", product.Name, product.Price, product.Category.Name);
                }

                Console.WriteLine();

                // Alle Kategorien mit den Produkten
                foreach (Category category in ctx.Categories)
                {
                    Console.WriteLine("Kategorie: {0}", category.Name);

                    foreach (Product product in category.Products)
                    {
                        Console.WriteLine("\t - {0}", product.Name);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void Update(ProductContext ctx)
        {
            try
            {
                // Den Preis für jede Support-Dienstleistung um 10€ erhöhen
                var supportProducts = (from c in ctx.Categories
                                       where c.Name.Equals("Support")
                                       select c).First().Products;

                foreach (var p in supportProducts)
                {
                    p.Price += 10;
                }

                ctx.SaveChanges();

                Console.WriteLine("Daten aktualisiert!");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void Delete(ProductContext ctx)
        {
            try
            {
                Category supportCat = (from c in ctx.Categories
                                       where c.Name.Equals("Support")
                                       select c).First();

                // Alle Produkte in der Kategorie löschen
                supportCat.Products.ToList().ForEach(p => ctx.Products.Remove(p));

                // Die Kategorie löschen
                ctx.Categories.Remove(supportCat);

                ctx.SaveChanges();

                Console.WriteLine("Daten gelöscht!");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}