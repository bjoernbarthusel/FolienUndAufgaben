﻿using UnitTest_GroßKlein;
using Xunit;

namespace TestProject
{
    public class UnitTest1
    {
        [Fact]
        public void Empty()
        {
            const string expected = "";

            Assert.Equal(expected, Program.ToTitleCase(string.Empty));
        }

        [Fact]
        public void Character()
        {
            const string expected = "A";

            Assert.Equal(expected, Program.ToTitleCase("a"));
            Assert.Equal(expected, Program.ToTitleCase("A"));
        }

        [Fact]
        public void Word()
        {
            const string expected = "Abc";

            Assert.Equal(expected, Program.ToTitleCase("abc"));
            Assert.Equal(expected, Program.ToTitleCase("ABC"));
            Assert.Equal(expected, Program.ToTitleCase("aBC"));
            Assert.Equal(expected, Program.ToTitleCase("Abc"));
        }

        [Fact]
        public void Number()
        {
            const string expected = "1abc";

            Assert.Equal(expected, Program.ToTitleCase("1abc"));
            Assert.Equal(expected, Program.ToTitleCase("1ABC"));
            Assert.Equal(expected, Program.ToTitleCase("1aBC"));
            Assert.Equal(expected, Program.ToTitleCase("1Abc"));
        }

        [Fact]
        public void Sentence()
        {
            const string expected = "Abc Def Ghi";

            Assert.Equal(expected, Program.ToTitleCase("abc def ghi"));
        }

        [Fact]
        public void MultipleWhitespace()
        {
            const string expected = "  Abc  Def Ghi ";

            Assert.Equal(expected, Program.ToTitleCase("  abc  def ghi "));
            Assert.Equal(expected, Program.ToTitleCase("  ABC  DEF GHI "));
        }
    }
}