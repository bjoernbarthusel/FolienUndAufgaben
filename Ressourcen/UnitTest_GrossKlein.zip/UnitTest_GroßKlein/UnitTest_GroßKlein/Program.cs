﻿using System;
using System.Text;

namespace UnitTest_GroßKlein
{
    public class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }

        public static string ToTitleCase(string sentence)
        {
            if (string.IsNullOrWhiteSpace(sentence))
            {
                return sentence;
            }

            StringBuilder result = new StringBuilder(sentence);

            result[0] = char.ToUpper(result[0]);

            for (int i = 1; i < result.Length; i++)
            {
                // Wenn das vorherige Zeichen ein Leerzeichen ist, dann in Großbuchstaben umwandeln
                result[i] = char.IsWhiteSpace(result[i - 1]) ? char.ToUpper(result[i]) : char.ToLower(result[i]);
            }

            return result.ToString();
        }
    }
}