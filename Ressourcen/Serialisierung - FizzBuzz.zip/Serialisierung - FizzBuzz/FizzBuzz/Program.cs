﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace FizzBuzz
{
    class Program
    {
        private static void Main(string[] args)
        {
            List<Factor> factors = ReadJsonFile();
            //List<Factor> factors = GetTestData();

            FizzBuzz fizzBuzz = new FizzBuzz(200, factors);
            Console.WriteLine(fizzBuzz.GetOutputSting());
        }

        private static List<Factor> ReadJsonFile()
        {
            const string path = "factors.json";
            string json = File.ReadAllText(path);
            return JsonSerializer.Deserialize<List<Factor>>(json);
        }

        private static List<Factor> GetTestData()
        {
            return new List<Factor>
            {
                new Factor() { Value = 3, Output = "Fizz" },
                new Factor() { Value = 5, Output = "Buzz" },
                new Factor() { Value = 7, Output = "Blubb" }
            };
        }
    }
}