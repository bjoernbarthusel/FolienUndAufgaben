﻿using System;
using System.Collections.Generic;

namespace FizzBuzz
{
    class FizzBuzz
    {
        private readonly int limit;

        private readonly List<Factor> factors;

        public FizzBuzz(int limit, List<Factor> factors)
        {
            this.limit = limit;
            this.factors = factors;
        }

        public string GetOutputSting()
        {
            string output = string.Empty;

            for (int i = 1; i <= limit; i++)
            {
                bool factorFound = false;

                foreach (Factor factor in factors)
                {
                    // Aktuelle Zahl ohne Rest durch
                    // einen der Faktoren aus der Liste teilbar?
                    if (i % factor.Value == 0)
                    {
                        // Faktorwort anstelle der Zahl ausgeben
                        // und merken
                        output += factor.Output;
                        factorFound = true;
                    }
                }

                // Kein Faktor gefunden, Zahl ausgeben
                if (factorFound == false)
                {
                    output += i.ToString();
                }

                if (i != limit)
                {
                    output += ", ";
                    //output += Environment.NewLine;
                }
            }

            return output;
        }
    }
}