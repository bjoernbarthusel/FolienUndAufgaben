﻿namespace FizzBuzz
{
    class Factor
    {
        public int Value { get; set; }
        public string Output { get; set; }
    }
}